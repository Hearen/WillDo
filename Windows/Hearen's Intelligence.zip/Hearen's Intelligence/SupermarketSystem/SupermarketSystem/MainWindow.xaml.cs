﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SupermarketSystem.panels;
using SupermarketSystem.globals;

namespace SupermarketSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Globals Global = (App.Current as App).Global;
        public MainWindow()
        {
            InitializeComponent();
            Global.init();
            setNotifications();
            this.Hide();
            Login_Panel loginWindow = new Login_Panel(this);
            loginWindow.Show();
        }

        private void setNotifications()
        {
            if (Global.ProductExpirationShowList.Count() > 0)
            {
                this.expireCountGrid.Visibility = System.Windows.Visibility.Visible;
                this.expireCountLabel.Content = Global.ProductExpirationShowList.Count.ToString();
            }
            else this.expireCountGrid.Visibility = System.Windows.Visibility.Collapsed;

            if (Global.ProductShortageShowList.Count() > 0)
            {
                this.shortageCountGrid.Visibility = Visibility.Visible;
                this.shortageCountLabel.Content = Global.ProductShortageShowList.Count.ToString();
            }
            else this.shortageCountGrid.Visibility = Visibility.Collapsed;
        }

        private void Window_Activated(object sender, EventArgs e)
        {
            setNotifications();
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (Global.AppIsClosing) 
            {
                Global.dispose();
                Application.Current.Shutdown(); 
                return; 
            }
            if (!Global.AppIsClosing && MessageBox.Show("Exit the system?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.dispose();
                Global.AppIsClosing = true;
                Application.Current.Shutdown();
            }
            else e.Cancel = true;
        }

        private void expirationButton_Click(object sender, RoutedEventArgs e)
        {
            Expiration_Panel expirationWindow;
            if (Global.WindowsDict.ContainsKey(Constants.ExpirationWindowKey))
            {
                expirationWindow = Global.WindowsDict[Constants.ExpirationWindowKey] as Expiration_Panel;
            }
            else
            {
                Global.WindowsDict[Constants.ExpirationWindowKey] = expirationWindow = new Expiration_Panel(this);
            }
            this.Hide();
            expirationWindow.Show();
        }

        private void shortageButton_Click(object sender, RoutedEventArgs e)
        {
            Shortage_Panel shortageWindow = new Shortage_Panel(this);
            if (Global.WindowsDict.ContainsKey(Constants.ShortageWindowKey))
            {
                shortageWindow = Global.WindowsDict[Constants.ShortageWindowKey] as Shortage_Panel;
            }
            else
            {
                Global.WindowsDict[Constants.ShortageWindowKey] = shortageWindow = new Shortage_Panel(this);
            }
            this.Hide();
            shortageWindow.Show();
        }

        private void productButton_Click(object sender, RoutedEventArgs e)
        {
            Products_Panel productWindow = new Products_Panel(this);
            if (Global.WindowsDict.ContainsKey(Constants.ProductWindowKey))
            {
                productWindow = Global.WindowsDict[Constants.ProductWindowKey] as Products_Panel;
            }
            else
            {
                Global.WindowsDict[Constants.ProductWindowKey] = productWindow = new Products_Panel(this);
            }
            this.Hide();
            productWindow.Show();
        }

        private void casherEvaluationButton_Click(object sender, RoutedEventArgs e)
        {
            StaffEveluator_Panel casherEvaluationWindow = new StaffEveluator_Panel(this);
            if (Global.WindowsDict.ContainsKey(Constants.StaffEvaluationWindowKey))
            {
                casherEvaluationWindow = Global.WindowsDict[Constants.StaffEvaluationWindowKey] as StaffEveluator_Panel;
            }
            else
            {
                Global.WindowsDict[Constants.ProductWindowKey] = casherEvaluationWindow = new StaffEveluator_Panel(this);
            }
            this.Hide();
            casherEvaluationWindow.Show();
        }

        private void premiumButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Wanna check more advanced features? Now become a subscriber of Hearen's Intelligence!");
        }

    }
}
