﻿using SupermarketSystem.entities;
using SupermarketSystem.tools;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace SupermarketSystem.globals
{
    public class Globals
    {
        public bool AppIsClosing = false;
        public List<string> Roles;
        public List<staff> StaffList;
        public ObservableCollection<product> ProductList; //the whole products list containing all the products;
        public ObservableCollection<product> ProductExpirationShowList; //all the products to expire which still not processed by the manager;
        public ObservableCollection<product> ProductShortageShowList; //all the products to be out of stock and meantime not confirmed procuring by the manager;
        XmlReaderAndWriter xmlReader = new XmlReaderAndWriter();
        public Dictionary<string, Window> WindowsDict = new Dictionary<string,Window>();
        public bool DispatchConfirmed = false;

        
        public void init()
        {
            Roles = xmlReader.readRolesFromXml();
            Roles.Insert(0, "- Select Role -");
            xmlReader.readConfigFromXml();
            StaffList = xmlReader.readStaffsFromXml();
            ProductList = xmlReader.readProductsFromXml();
            updateExpirationShowList();
            updateShortageShowList();
        }

        //write down all changes modified by the user;
        public void dispose()
        {
            xmlReader.writeProductsToXml(ProductList);
        }

        //remove all the prducts that are to expire but manually labeled by the manager to be `tooEarly` or `tooLate` or manually remove the warning;
        public void updateExpirationShowList()
        {
            if (ProductExpirationShowList == null) ProductExpirationShowList = new ObservableCollection<product>();
            ProductExpirationShowList.Clear();
            foreach (product p in ProductList) //only adjust one level each time;
            {
                if (!p.TooEarly && !p.TooLate && !p.Expiration_Warning_Removed && p.WithinExpireRedArea) ProductExpirationShowList.Add(p);
            }
        }

        //once the manager confirm the procuring process, then the warning should be removed from the list;
        public void updateShortageShowList()
        {
            if (ProductShortageShowList == null) ProductShortageShowList = new ObservableCollection<product>();
            ProductShortageShowList.Clear();
            foreach (product p in ProductList)
            {
                if (p.WithinShortageRedArea && !p.procureConfirmed) ProductShortageShowList.Add(p);
            }
        }
    }
}
