﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketSystem.globals
{
    static class Constants
    {
        public const string ExpirationWindowKey = "ExpirationWindow";
        public const string ShortageWindowKey = "ShortageWindow";
        public const string ProductWindowKey = "ProductWindow";
        public const string StaffEvaluationWindowKey = "StaffEvaluationWindow";

        public const double ExpirationThreshold = 0.15;
    }
}
