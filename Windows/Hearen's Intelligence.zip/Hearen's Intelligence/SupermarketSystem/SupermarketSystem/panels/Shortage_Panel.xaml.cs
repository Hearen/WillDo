﻿using SupermarketSystem.globals;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketSystem.panels
{
    /// <summary>
    /// Interaction logic for Shortage_Panel.xaml
    /// </summary>
    public partial class Shortage_Panel : Window
    {
        Globals Global = (App.Current as App).Global;
        MainWindow mainWindow;
        public Shortage_Panel(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            InitializeComponent();
            Global.updateShortageShowList();
            this.listView.ItemsSource = Global.ProductShortageShowList;
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Global.AppIsClosing && MessageBox.Show("Exit the system?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.AppIsClosing = true;
                this.mainWindow.Close();
            }
            else e.Cancel = true;
        }


        private void goBack_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.mainWindow.Activate();
            this.mainWindow.Show();
        }

        private void dispatchButton_Click(object sender, RoutedEventArgs e)
        {
            List<product> productList = new List<tools.product>();
            foreach (product p in Global.ProductShortageShowList)
            {
                if (p.ProcureConfirmed) productList.Add(p);
            }
            Dispatch_Popup dispatchPopup = new Dispatch_Popup(Constants.ShortageWindowKey, productList);
            dispatchPopup.Show();
            dispatchPopup.Focus();
            dispatchPopup.Topmost = true;
        }

        private void allCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox.IsChecked == true)
            {
                foreach (product p in Global.ProductShortageShowList)
                {
                    p.ProcureConfirmed = true;
                }
                //this.listView.ItemsSource = Global.ProductExpirationShowList;
            }
            else
            {
                foreach (product p in Global.ProductShortageShowList)
                {
                    p.ProcureConfirmed = false;
                }
            }
        }
    }
}
