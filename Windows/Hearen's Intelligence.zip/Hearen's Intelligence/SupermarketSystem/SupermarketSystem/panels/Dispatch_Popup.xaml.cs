﻿using SupermarketSystem.entities;
using SupermarketSystem.globals;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketSystem.panels
{
    /// <summary>
    /// Interaction logic for Dispatch_Popup.xaml
    /// </summary>
    public partial class Dispatch_Popup : Window
    {
        string sourceWindowKey;
        List<product> productList;
        private const string ExpirationTitle = "Expiration Warning - Promotion";
        private const string ShortageTitle = "Shortage Warning - Procure";
        Globals Global = (App.Current as App).Global;
        private List<staff> staffList;
        public Dispatch_Popup(String sourceWindowKey, List<product> productList)
        {
            this.sourceWindowKey = sourceWindowKey;
            this.productList = productList;
            this.staffList = Global.StaffList;
            InitializeComponent();
            this.warningLabel.Visibility = Visibility.Collapsed;
            initPopup();
        }

        private void initPopup()
        {
            this.listView.ItemsSource = this.productList;
            switch(this.sourceWindowKey)
            {
                case Constants.ExpirationWindowKey: this.titleLable.Content = ExpirationTitle; break;
                case Constants.ShortageWindowKey: this.titleLable.Content = ShortageTitle; break;
                default: break;
            }
        }
        bool prefixExistInStaffs(string prefix)
        {
            foreach (staff t in staffList)
            {
                if (t.Name.Contains(prefix) || t.ID.Contains(prefix)) return true;
            }
            return false;
        }

        private void staffTB_TextChanged(object sender, TextChangedEventArgs e)
        {
            string prefix = this.staffTB.Text;
            if (prefix == null || prefix == "Staff ID/Name") return;
            if (prefixExistInStaffs(prefix))
            {
                this.warningLabel.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.warningLabel.Visibility = Visibility.Visible;
            }
        }

        private bool existInStaffs(string s)
        {
            foreach (staff t in staffList)
            {
                if (t.Name == s || t.ID == s) return true;
            }
            return false;
        }

        private void staffTB_LostFocus(object sender, RoutedEventArgs e)
        {
            string prefix = this.staffTB.Text;
            if (prefix == null || prefix == "Staff ID/Name") return;
            if (existInStaffs(prefix))
            {
                this.warningLabel.Visibility = Visibility.Collapsed;
            }
            else
            {
                this.warningLabel.Visibility = Visibility.Visible;
            }
        }

        bool _firstGotFocus = true;
        private void staffTB_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_firstGotFocus)
            {
                this.staffTB.Text = "";
                _firstGotFocus = false;
            }
        }

        /// <summary>
        /// update the state of the parent window;
        /// </summary>
        private void updateParentWindow()
        {
            switch (this.sourceWindowKey)
            {
                case Constants.ExpirationWindowKey:
                    {
                        Expiration_Panel expirationWindow = Global.WindowsDict[Constants.ExpirationWindowKey] as Expiration_Panel;
                        Global.updateExpirationShowList();
                        expirationWindow.listView.ItemsSource = Global.ProductExpirationShowList;
                        break;
                    }
                case Constants.ShortageWindowKey:
                    {
                        Shortage_Panel shortageWindow = Global.WindowsDict[Constants.ShortageWindowKey] as Shortage_Panel;
                        Global.updateShortageShowList();
                        shortageWindow.listView.ItemsSource = Global.ProductShortageShowList;
                        break;
                    }
                default: break;
            }
        }

        /// <summary>
        /// update the state of the parent window, since the user confirm the current operation;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void confirmButton_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Are you sure you wanna assign this to task " + this.staffTB.Text + "?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.DispatchConfirmed = true;
                updateParentWindow();
                this.Close();
            }
            else Global.DispatchConfirmed = false;
        }

        /// <summary>
        /// reset the data of the parent window if the user cancels the current operation;
        /// </summary>
        private void resetParentWindow()
        {
            switch (this.sourceWindowKey)
            {
                case Constants.ExpirationWindowKey:
                    {
                        foreach (product p in Global.ProductExpirationShowList)
                            p.Expiration_Warning_Removed = false;
                        break;
                    }
                case Constants.ShortageWindowKey:
                    {
                        foreach (product p in Global.ProductShortageShowList)
                            p.ProcureConfirmed = false;
                        break;
                    }
                default: break;
            }
        }

        /// <summary>
        /// If cancel the dispatching operation by closing the popup window directly;
        /// we have to reset the parent window and all the related data;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            resetParentWindow();
        }

        
    }
}
