﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using SupermarketSystem.tools;
using SupermarketSystem.panels;
using SupermarketSystem.globals;
using SupermarketSystem.entities;

namespace SupermarketSystem.panels
{
    /// <summary>
    /// Interaction logic for Login_Panel.xaml
    /// </summary>
    public partial class Login_Panel : Window
    {
        Globals Global = (App.Current as App).Global;
        private MainWindow mainWindow;
        public Login_Panel(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            InitializeComponent();
            this.rolesComboBox.ItemsSource = Global.Roles;
            this.rolesComboBox.SelectedIndex = Config.PrevRoleIndex;
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Global.AppIsClosing && MessageBox.Show("Exit the system?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.AppIsClosing = true;
                Application.Current.Shutdown();
            }
            else e.Cancel = true;
        }

        private void idTextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            textBox.Text = "";
            textBox.Foreground = Brushes.Black;
        }

        private void passwordBox_GotFocus(object sender, RoutedEventArgs e)
        {
            PasswordBox passwordBox = sender as PasswordBox;
            passwordBox.Password = "";
            passwordBox.Foreground = Brushes.Black;
        }

        void login_check(bool check)
        {
            string role = check? rolesComboBox.SelectedValue as string : "Manager";
            string name = check? nameTextBox.Text as string : "hearen";
            string pwd = check? pwdBox.Password as string : "hearen";
            if (role == "Manager" && name == "hearen" && pwd == "hearen")
            {
                this.mainWindow.Show();
                this.Hide();
                Config.PrevRoleIndex = this.rolesComboBox.SelectedIndex;
            }
            else
            {
                MessageBox.Show("Wrong user name or password!");
            }
        }

        private void signIn_Click(object sender, RoutedEventArgs e)
        {
            login_check(true);
        }

        private void pwdBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                login_check(true);
            }
        }

        
    }
}
