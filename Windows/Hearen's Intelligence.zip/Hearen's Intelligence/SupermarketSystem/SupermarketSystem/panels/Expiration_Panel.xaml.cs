﻿using SupermarketSystem.tools;
using SupermarketSystem.globals;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketSystem.panels
{
    /// <summary>
    /// Interaction logic for Expiration_Panel.xaml
    /// </summary>
    public partial class Expiration_Panel : Window
    {
        Globals Global = (App.Current as App).Global;
        MainWindow mainWindow;
        public Expiration_Panel(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            InitializeComponent();
            Global.updateExpirationShowList();
            this.listView.ItemsSource = Global.ProductExpirationShowList;
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Global.AppIsClosing && MessageBox.Show("Exit the system?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.AppIsClosing = true;
                this.mainWindow.Close();
            }
            else e.Cancel = true;
        }


        //detect the window showing event;
        bool _shown = false;

        protected override void OnContentRendered(EventArgs e)
        {
            base.OnContentRendered(e);

            if (_shown)
                return;

            _shown = true;
            Global.updateExpirationShowList();
            this.listView.ItemsSource = Global.ProductExpirationShowList; 
        }



        private void delayCB_Checked_1(object sender, RoutedEventArgs e)
        {
            if ((sender as CheckBox).IsChecked == true)
            {
                Global.updateExpirationShowList();
                this.listView.ItemsSource = Global.ProductExpirationShowList;
            }
        }

        private void tooLateCB_Checked_1(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Sorry to warn you this late, I'll warn you earlier next time!");
            CheckBox checkBox = sender as CheckBox;
            checkBox.IsEnabled = false;
        }

        private void goBack_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            mainWindow.Activate();
            mainWindow.Show();
        }

        private void dispatchButton_Click(object sender, RoutedEventArgs e)
        {
            List<product> productList = new List<tools.product>();
            foreach(product p in Global.ProductExpirationShowList)
            {
                if (p.Expiration_Warning_Removed) productList.Add(p);
            }
            Dispatch_Popup dispatchPopup = new Dispatch_Popup(Constants.ExpirationWindowKey, productList);
            dispatchPopup.Show();
            dispatchPopup.Focus();
            dispatchPopup.Topmost = true;
        }

        private void allCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            CheckBox checkBox = sender as CheckBox;
            if (checkBox.IsChecked == true)
            {
                foreach (product p in Global.ProductExpirationShowList)
                {
                    p.Expiration_Warning_Removed = true;
                }
                //this.listView.ItemsSource = Global.ProductExpirationShowList;
            }
            else
            {
                foreach (product p in Global.ProductExpirationShowList)
                {
                    p.Expiration_Warning_Removed = false;
                }
            }
        }
    }
}
