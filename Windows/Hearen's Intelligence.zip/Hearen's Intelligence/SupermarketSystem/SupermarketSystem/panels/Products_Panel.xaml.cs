﻿using SupermarketSystem.globals;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace SupermarketSystem.panels
{
    /// <summary>
    /// Interaction logic for Products_Panel.xaml
    /// </summary>
    public partial class Products_Panel : Window
    {
        Globals Global = (App.Current as App).Global;
        MainWindow mainWindow;
        public Products_Panel(MainWindow mainWindow)
        {
            this.mainWindow = mainWindow;
            InitializeComponent();
            Global.updateExpirationShowList();
            this.listView.ItemsSource = Global.ProductList;
            this.countLabel.Content = Global.ProductList.Count().ToString() + " products here";
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!Global.AppIsClosing && MessageBox.Show("Exit the system?", "", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
            {
                Global.AppIsClosing = true;
                this.mainWindow.Close();
            }
            else e.Cancel = true;
        }


        private void goBack_Click(object sender, RoutedEventArgs e)
        {
            this.Hide();
            this.mainWindow.Activate();
            this.mainWindow.Show();
        }


    }
}
