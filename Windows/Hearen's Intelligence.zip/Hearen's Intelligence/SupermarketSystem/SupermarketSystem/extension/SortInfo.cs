﻿using System.Windows.Controls;

namespace SupermarketSystem.extension
{
    public class SortInfo
    {
        public GridViewColumnHeader LastSortColumn { get; set; }

        public UIElementAdorner CurrentAdorner { get; set; }
    }
}
