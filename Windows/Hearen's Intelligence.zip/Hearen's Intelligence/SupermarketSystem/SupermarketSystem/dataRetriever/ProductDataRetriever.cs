﻿using SupermarketSystem.globals;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketSystem.dataRetriever
{
    public static class ProductDataRetriever
    {
        /// <summary>
        /// Used to locate the proper time to warn the manager about the expiration which can be best used to deal with the products to expire;
        /// Focusing on the most significant factors while ignoring the secondary ones - neat and efficient with the sensitivity ratio;
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static int RetrieveExpireRedArea(product p)
        {
            return (int)(double.Parse(p.SensitivityRatio) * p.Durability * Constants.ExpirationThreshold) + 1;
        }

        /// <summary>
        /// Model based on EWMA (Exponentially Weighted Moving Average) 
        /// speed(t) = a*Y(t)+(1-a)*speed(t-1)+Q(t) 
        /// Q(t) here is used to handle special cases - moon cake;
        /// </summary>
        /// <param name="p"></param>
        /// <returns></returns>
        public static int RetrieveSellingSpeed(product p)
        {
            return p.SellingSpeed;
        }
    }
}
