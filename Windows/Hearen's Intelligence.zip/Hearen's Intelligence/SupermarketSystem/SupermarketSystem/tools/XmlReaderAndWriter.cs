﻿using SupermarketSystem.entities;
using SupermarketSystem.tools;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace SupermarketSystem.tools
{
    public class XmlReaderAndWriter
    {
        public void writeRolesToXml(List<string> roles, string path = "data/roles.xml")
        {
            XmlTextWriter writer = new XmlTextWriter(path, System.Text.Encoding.UTF8);
            writer.Formatting = Formatting.Indented;///for better readability;

            writer.WriteStartDocument();
            writer.WriteStartElement("roles");
            foreach (string role in roles)
            {
                writer.WriteElementString("role", role);
            }
            writer.WriteEndElement();
            writer.Close();
        }

        public List<string> readRolesFromXml(string path = "data/roles.xml")
        {
            List<string> roles = new List<string>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(path);
            XmlNodeList nodeList = xmlDoc.GetElementsByTagName("role");
            foreach (XmlNode child in nodeList)
            {
                roles.Add(child.InnerText);
            }
            return roles;
        }

        public List<staff> readStaffsFromXml(string path = "data/staffs.xml")
        {
            List<staff> staffList = new List<staff>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(path);
            XmlNodeList nodeList = xmlDoc.GetElementsByTagName("staff");
            foreach (XmlNode node in nodeList)
            {
                staff t = new staff();
                foreach (XmlNode child in node)
                {
                    switch (child.Name)
                    {
                        case "id": t.ID = child.InnerText as string; break;
                        case "name": t.Name = child.InnerText as string; break;
                        
                        default: break;
                    }
                }
                staffList.Add(t);
            }
            return staffList;
        }

        public ObservableCollection<product> readProductsFromXml(string path = "data/products.xml")
        {
            ObservableCollection<product> productList = new ObservableCollection<product>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(path);
            XmlNodeList nodeList = xmlDoc.GetElementsByTagName("product");
            foreach (XmlNode node in nodeList)
            {
                product t = new product();
                foreach (XmlNode child in node)
                {
                    switch (child.Name)
                    {
                        case "id": t.ProductID = child.InnerText as string; break;
                        case "name": t.ProductName = child.InnerText as string; break;
                        case "days2Expire": t.DaysToExpire = int.Parse(child.InnerText); break;
                        case "durability": t.Durability = int.Parse(child.InnerText); break;
                        case "sensitivityRatio": t.sensitivityRatio = double.Parse(child.InnerText); break;
                        case "expirationWarningRemoved": t.Expiration_Warning_Removed = int.Parse(child.InnerText) == 0 ? false : true; break;
                        case "sellingSpeed": t.SellingSpeed = int.Parse(child.InnerText); break;
                        case "days2Procure": t.DaysToProcure = int.Parse(child.InnerText); break;
                        case "stock": t.Stock = int.Parse(child.InnerText); break;
                        case "procureConfirmed": t.ProcureConfirmed = int.Parse(child.InnerText) == 0 ? false : true; break;
                        default: break;
                    }
                }
                productList.Add(t);
            }
            return productList;
        }

        public void readConfigFromXml(string path = "data/config.xml")
        {
            ObservableCollection<product> productList = new ObservableCollection<product>();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(path);
            XmlNode node = xmlDoc.GetElementsByTagName("config")[0];
            foreach (XmlNode child in node.ChildNodes)
            {
                switch (child.Name)
                {
                    case "roleIndex": Config.PrevRoleIndex = int.Parse(child.InnerText); break;
                    default: break;
                }
            }
        }

        public void writeConfToXml(string path = "data/conf.xml")
        {
            XmlTextWriter writer = new XmlTextWriter(path, System.Text.Encoding.UTF8);
            writer.Formatting = Formatting.Indented;///for better readability;

            writer.WriteStartDocument();

            ///start products tag;
            writer.WriteStartElement("config");
            writer.WriteElementString("roleIndex", Config.PrevRoleIndex.ToString());
            writer.WriteEndElement();
            writer.Close();
        }

        public void writeProductsToXml(ObservableCollection<product> productList, string path = "data/products.xml")
        {
            XmlTextWriter writer = new XmlTextWriter(path, System.Text.Encoding.UTF8);
            writer.Formatting = Formatting.Indented;///for better readability;

            writer.WriteStartDocument();

            ///start products tag;
            writer.WriteStartElement("products");
            foreach (product t in productList)
            {
                ///start the inner single item tag;
                writer.WriteStartElement("product");
                writer.WriteElementString("id", t.ProductID);
                writer.WriteElementString("name", t.ProductName);
                writer.WriteElementString("days2Expire", t.DaysToExpire.ToString());
                writer.WriteElementString("durability", t.Durability.ToString());
                writer.WriteElementString("sensitivityRatio", t.sensitivityRatio.ToString());
                writer.WriteElementString("expirationWarningRemoved", t.Expiration_Warning_Removed? "1":"0");
                writer.WriteElementString("sellingSpeed", t.SellingSpeed.ToString());
                writer.WriteElementString("days2Procure", t.DaysToProcure.ToString());
                writer.WriteElementString("stock", t.Stock.ToString());
                writer.WriteElementString("procureConfirmed", t.procureConfirmed? "1":"0");
                writer.WriteEndElement();
                ///end the singular item tag;
            }
            writer.WriteEndElement();///end products tag;
            writer.Close();
        }
    }
}
