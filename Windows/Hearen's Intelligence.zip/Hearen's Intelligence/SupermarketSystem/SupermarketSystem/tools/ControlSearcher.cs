﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace SupermarketSystem.tools
{
    public static class ControlSearcher
    {

        public static List<ChildType> FindVisualChildren<ChildType>(DependencyObject obj) where ChildType : DependencyObject
        {
            List<ChildType> childList = new List<ChildType>();
            if (obj == null) return childList;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(obj); i++)
            {
                DependencyObject child = VisualTreeHelper.GetChild(obj, i);
                if (child != null && child is ChildType)
                {
                    childList.Add(child as ChildType);
                }
                else
                {
                    List<ChildType> childOfChildren = FindVisualChildren<ChildType>(child);
                    if (childOfChildren.Count() > 0)
                    {
                        childList.AddRange(childOfChildren);
                    }
                }
            }
            return childList;

        }
    }
}
