﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketSystem.entities
{
    public class Config
    {
        public static int PrevRoleIndex = 0;
    }
}
