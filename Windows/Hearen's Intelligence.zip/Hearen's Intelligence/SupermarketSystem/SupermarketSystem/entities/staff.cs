﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketSystem.entities
{
    public class staff
    {
        public string ID { set; get; } //the unique ID for each staff;
        public string Name { set; get; } //the default unique ID for staff - actually this premise should be wrong;
    }
}
