﻿using SupermarketSystem.dataRetriever;
using SupermarketSystem.globals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupermarketSystem.tools
{
    public class product : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public string ProductID { set; get; } //unique ID to identify the product item;
        public string ProductName { set; get; } //name to identify the product but not unique - can be simply retrieved from DB;
        public int DaysToExpire { set; get; } //the time left to expire - can be simply retrieved from DB;
        public int Durability { set; get; } //the whole quality guarantee period - can be simply retrieved from DB;
        public double sensitivityRatio { set; get; } //used to collect the feedback from the manager to adjust the expiration auto-warning;
        private bool tooEarly; //delayed by the manager or not;
        private bool tooLate; //too late to warn the manager;
        private bool expiration_Warning_Removed; //used to label the expiration warning handled;

        private int sellingSpeed; //the predicted selling speed;
        public int DaysToProcure { set; get; } //the time (day) procuring requires;
        public int Stock { set; get; } //the current stock;
        public bool procureConfirmed; //indicate whether the warning is handled or not; 

        //from an sensitive mode to gradually blend in the ideal states by user feedbacks;
        //percent*durability + 1day;
        public bool WithinExpireRedArea
        {
            get
            {
                return DaysToExpire <= ProductDataRetriever.RetrieveExpireRedArea(this);
            }
        }
        
        //used to present the double in the table with decimals;
        public string SensitivityRatio
        {
            get
            {
                return sensitivityRatio.ToString();
            }
        }

        public bool TooEarly
        {
            get { return tooEarly; }
            set
            {
                tooEarly = value;
                if (sensitivityRatio > 0) sensitivityRatio -= 0.1;
            }
        }

        public bool TooLate
        {
            get { return tooLate; }
            set
            {
                tooLate = value;
                if (sensitivityRatio > 0) sensitivityRatio += 0.1;
            }
        }

        public bool Expiration_Warning_Removed
        {
            get { return expiration_Warning_Removed;  }
            set
            {
                expiration_Warning_Removed = value;
                if (this.PropertyChanged != null)
                {
                    this.PropertyChanged.Invoke(this, new PropertyChangedEventArgs("Expiration_Warning_Removed"));
                }
            }
        }

        public bool WithinShortageRedArea
        {
            get //have to ensure there are enough time to procure the products back to the stock;
            {
                return DaysToProcure >= Stock / sellingSpeed;
            }
        }

        public int SellingSpeed
        {
            set { sellingSpeed = value;  }
            get
            {
                WarningLevel = 10*(DaysToProcure - Stock / sellingSpeed) / DaysToProcure + 1;
                if (WarningLevel > 10) WarningLevel = 10;
                //according to the history based on EWMA model (Exponentially Weighted Moving Average);
                //return ProductDataRetriever.RetrieveSellingSpeed();
                return sellingSpeed;
            }
        }

        public int SoldOut
        {
            get { return Stock / sellingSpeed; }
        }

        public bool ProcureConfirmed
        {
            get
            {
                return procureConfirmed; //this value should be retrieved from DB;
            }
            set
            {
                procureConfirmed = value; //normally this value will be labeled and deleted after a peroid of time from DB;
                if (this.PropertyChanged != null)
                {
                    this.PropertyChanged.Invoke(this, new PropertyChangedEventArgs("ProcureConfirmed"));
                }
            }
        }


        public string WarningLevelColor { set; get; }

        private int warningLevel;

        /// <summary>
        /// used to indicate how severe it is to be out of stock in the near future;
        /// </summary>
        public int WarningLevel
        {
            get { return warningLevel; }
            set
            {
                warningLevel = value;//once priority changed, change the corresponding priorityColor;
                switch (warningLevel)
                {
                    //using PriorityColor instead of priorityColor;
                    //make sure the propertychanged event will be invoked inside PriorityColor
                    case 1: WarningLevelColor = "LightBlue"; break;
                    case 2: WarningLevelColor = "LightSkyBlue"; break;
                    case 3: WarningLevelColor = "DeepSkyBlue"; break;
                    case 4: WarningLevelColor = "MediumBlue"; break;
                    case 5: WarningLevelColor = "Navy"; break;
                    case 6: WarningLevelColor = "MidnightBlue"; break;
                    case 7: WarningLevelColor = "HotPink"; break;
                    case 8: WarningLevelColor = "DeepPink"; break;
                    case 9: WarningLevelColor = "Red"; break;
                    case 10: WarningLevelColor = "DarkRed"; break;
                    default: WarningLevelColor = "Navy"; break;
                }
                if (this.PropertyChanged != null)
                {
                    this.PropertyChanged.Invoke(this, new PropertyChangedEventArgs("WarningLevel"));
                    //this.PropertyChanged.Invoke(this, new PropertyChangedEventArgs("PriorityColor"));//may be something wrong about this usage;
                }
            }
        }
    }
}
